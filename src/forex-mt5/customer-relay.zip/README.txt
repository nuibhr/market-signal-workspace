Nugaom Customer MT5 Relay · Mac / Windows · Pilot v2.20

1. ใช้ MT5 Desktop ที่มี Expert Advisors และบัญชี Vantage
2. ติดตั้ง Node.js รุ่น 22 ขึ้นไปจาก https://nodejs.org
3. ในเว็บ HTTPS ของระบบ เลือก Server → ส่งผ่านไฟล์ → สร้างกุญแจ
   ดาวน์โหลด NugaomMT5.set และ NugaomRelay.json (ไฟล์ JSON มีกุญแจของคุณ เก็บไว้ส่วนตัว)
4. ใน MT5: File → Open Data Folder → MQL5 → Experts
   วาง NugaomReadOnlyBridge.ex5 แล้ว Refresh Navigator
5. ลาก EA ลงกราฟหนึ่งกราฟ → Inputs → Load → NugaomMT5.set → OK
   ไม่ต้องเพิ่ม WebRequest URL ไม่ต้องส่งรหัสผ่านหรือเปิดสิทธิ์ซื้อขาย
6. ใน Data Folder ไป MQL5/Files/NugaomBridge แล้วคัดลอกที่อยู่โฟลเดอร์
7. แตก ZIP บนเครื่องเดียวกับ MT5:
   Mac: เปิด Start-Mac.command (หรือใน Terminal ใช้ node customer-relay.mjs)
   Windows: เปิด Start-Windows.cmd
   ใส่ที่อยู่ไฟล์ NugaomRelay.json จากนั้นใส่ที่อยู่โฟลเดอร์ในข้อ 6
   ลากชื่อไฟล์ที่มีช่องว่างบน Mac: ใช้คัดลอกชื่อ path ตรง ๆ แทนรูปแบบ backslash escape
8. เปิด MT5 และหน้าต่างตัวส่งไฟล์ไว้ กลับหน้า Forex เพื่อตรวจจำนวนสินทรัพย์
   เวลา/ราคาจะเปิดเมื่อยืนยันเวลาปัจจุบันได้หลายครั้ง กราฟสะสมแท่งปิดหลังเริ่มตรวจเวลา
9. กุญแจหมดอายุ 7 วัน สร้างใหม่แล้วดาวน์โหลดไฟล์ตั้งค่าใหม่ทั้งสองไฟล์
   การยกเลิกกุญแจบนเว็บจะหยุดรับข้อมูลทันที

โปรแกรมอ่านเฉพาะไฟล์ channel ที่เลือกใน MT5 Files และส่งตลาดไป Endpoint HTTPS ที่กำหนด
ไม่อ่านเลขบัญชี ยอดเงิน พอร์ต หรือรหัสผ่าน และไม่มีคำสั่งซื้อขาย
สถานะนี้เป็นชุดทดสอบ: คอมไพล์บน Mac Wine X64 แล้ว ยังไม่ทดสอบ MT5 บน Windows จริง
ต้องเปิดตัวรับข้อมูลเว็บ HTTPS พร้อมระบบ LINE login เดิมก่อนให้ลูกค้าใช้งาน
