#!/bin/sh
cd -- "$(dirname -- "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
  echo "Install Node.js 22 or later from https://nodejs.org, then reopen this file."
  read relay_wait
  exit 1
fi
node customer-relay.mjs
read relay_wait
